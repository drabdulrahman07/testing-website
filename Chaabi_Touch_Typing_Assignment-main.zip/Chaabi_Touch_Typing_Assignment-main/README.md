# Chaabi_Touch_Typing_Assignment

Deployed Link :- https://touch-typing-81bc84.netlify.app/

Snap :- 

![image](https://user-images.githubusercontent.com/75311454/218293782-eba15288-b204-41f8-9208-9e03f7a4889c.png)
