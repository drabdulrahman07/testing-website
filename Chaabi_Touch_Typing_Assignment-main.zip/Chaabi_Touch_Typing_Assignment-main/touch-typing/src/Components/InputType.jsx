import React from "react";
import Random from "./Random";
import Compare from "./Compare";

function InputType() {
  return (
    <div>
      <Random />
      <Compare />
    </div>
  );
}

export default InputType;
