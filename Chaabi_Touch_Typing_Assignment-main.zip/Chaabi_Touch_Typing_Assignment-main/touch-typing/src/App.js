import "./App.css";
import Top from "./Components/Top";
import Home from "./Components/Home";

function App() {
  return (
    <div className="App">
      <Top/>
      <Home />
    </div>
  );
}

export default App;
